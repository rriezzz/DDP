from gempa import *

pertama.dampak()
kedua.dampak()
ketiga.dampak()
keempat.dampak()
kelima.dampak()